      <nav>
          <ul>
              <li><a href="#"> Main menu </a></li>
              <li><a href="#"> My pojects </a></li>
              <li><a href="#"> My articles </a></li>
              <li><a href="#"> Lincs </a></li>
              <li><a href="#"> Contacts </a></li>
          </ul>
      </nav>


